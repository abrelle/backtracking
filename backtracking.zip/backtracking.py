import sys
import networkx as nx
import matplotlib.pyplot as plt


def prepare_graph(graph):
    for index in range(len(graph.nodes)):
        g.nodes[index]['visited'] = 0
    return graph


def write_nodes(g):
    print("write")


def print_graph(g):
    print("graph")


def find_independent_set(graph):

    max_set = set()
    isolatedNodes = set()
    for node in graph.nodes:
        graph.nodes[node]['visited'] = 1
        new_set = backtrack_nodes(graph, node, {node})

        if len(new_set) > len(max_set):
            max_set = new_set

        if len(new_set) == 1:
            isolatedNodes.add(node)

    max_set.update(isolatedNodes)
    return max_set


def backtrack_nodes(graph, node, independentSet):
    neighbors = set(graph[node].keys())
    graph.nodes[node]['visited'] = 1
    if not(neighbors & independentSet):
        independentSet.add(node)

    for neighbor in neighbors:
        if graph.nodes[neighbor]['visited'] != 1:
            independentSet = backtrack_nodes(graph, neighbor, independentSet)
        print(independentSet)
    graph.nodes[node]['visited'] = 0

    return independentSet


if __name__ == '__main__':
    #nodes = int(sys.argv[1])
    #edges = int(sys.argv[2])
    g = nx.gnm_random_graph(5, 4)
   # print(nx.maximal_independent_set(g))
    # g = nx.Graph()
    # g.add_edge(0, 1)
    # g.add_edge(0, 4)
    # g.add_edge(1, 2)
    # g.add_edge(1, 3)
    # g.add_edge(2, 4)
    # g.add_edge(2, 5)
    # g.add_edge(2, 6)
    # g.add_edge(3, 5)
    # g.add_edge(3, 7)
    # g.add_edge(5, 7)
    # g.add_edge(8, 7)
    # g.add_edge(0, 1)
    # g.add_edge(1, 2)
    #
    # g.add_edge(3, 0)
    # g.add_edge(2, 3)
    # g.add_edge(2, 5)
    # g.add_edge(1, 4)

    prepare_graph(g)
    plt.subplot(121)
    nx.draw(g, with_labels=True, font_weight='bold')
    plt.show()
    visited = [0] * len(g.nodes)
    print(find_independent_set(g))
    if "-w" in sys.argv:
        write_nodes(g)
    if "-p" in sys.argv:
        print_graph(g)
